#ifndef BOOLS
#define BOOLS

bool isESP = false;
bool isESPLine = false;
bool isESPBox = false;
bool isESPObjectsCount = false;
bool isESPDistance = false;

bool bInitDone = false;

int screenWidth,screenHeight = 0;
bool g_Initialized = false;

ImGuiWindow* g_window = NULL;

#endif
