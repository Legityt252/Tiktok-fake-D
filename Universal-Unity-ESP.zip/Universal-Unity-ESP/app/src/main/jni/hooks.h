
// ESP without hooks credit Darkside
// My Telegram : @dark_fack
// Telegram channel : @darkrare
// I would be very grateful for modifications to this project

#ifndef HOOKS_H
#define HOOKS_H

#include <EGL/egl.h>
#include <GLES3/gl3.h>

#include "../imgui/imgui.h"
#include "../imgui/imgui_impl_android.h"
#include "../imgui/imgui_impl_opengl3.h"
#include "../imgui/imgui_internal.h"

#include "Unity/Vector3.hpp"
#include "Unity/Vector2.hpp"
#include "Unity/Rect.h"
#include "Unity/Quaternion.h"
#include "Unity/Color.h"

#include "ByNameModding/Tools.h"
#include "ByNameModding/fake_dlfcn.h"
#include "ByNameModding/Il2Cpp.h"

#include "Utils.h"
#include "bools.h"
#include "Drawing.h"

#define libName "libil2cpp.so"

void (*Screen_SetResolution)(int width, int height, bool fullscreen);
void *(*CameraManager_get_MainCamera)() = NULL;
void *(*Camera_get_main)() = NULL;
void *(*Camera_get_current)() = NULL;
void *(*Component_get_transform)(void *instance) = NULL;
Vector3 (*Transform_get_position)(void *instance) = NULL;
void *(*GameObject_get_transform)(void *instance) = NULL;
Vector3 (*Camera_WorldToScreen)(void *camera, Vector3 position) = NULL;
MonoArray<void**>*(*Object_FindObjectsOfType)(void*) = NULL;
void *(*Type_GetTypeName)(MonoString* typeStr) = NULL;
MonoArray<void**>*(*GameObject_FindGameObjectsWithTag)(MonoString*) = NULL;
bool *(*Object_IsNativeObjectAlive)(void *object) = NULL;
void *(*GameObject_get_gameObject)(void *original) = NULL;
void *(*Object_Destroy)(void* obj) = NULL;

bool m_CachedPtr(void *unity_obj) {
     return (unity_obj != nullptr && (*(uintptr_t*)((uintptr_t)unity_obj + 0x8))); //class Object -> private IntPtr m_CachedPtr; // 0x8
}

Vector3 Transform_getPosition(void *transform) {  
  return Transform_get_position(Component_get_transform(transform));
} 

Vector3 GameObject_getPosition(void *transform) {  
  return Transform_get_position(GameObject_get_transform(transform));
} 

void MenuDraw() {
    
     ImGuiIO &io = ImGui::GetIO();
    
     ImVec2 windowSize = ImVec2(screenWidth * 0.55, screenHeight * 0.23);
     ImGui::SetNextWindowSize(windowSize);
     
     if (ImGui::Begin("Universal-Unity-ESP", 0, ImGuiWindowFlags_NoSavedSettings)) {
        g_window = ImGui::GetCurrentWindow();
    
        if (ImGui::BeginTabBar("Tab", ImGuiTabBarFlags_FittingPolicyScroll)) {      
            if (ImGui::BeginTabItem("ESP MENU")) {              
                ImGui::Checkbox("Enable ESP", &isESP);             
                ImGui::Checkbox("ESP Line", &isESPLine);           
                ImGui::Checkbox("ESP Box", &isESPBox);             
                ImGui::Checkbox("ESP Distance", &isESPDistance);             
                ImGui::Checkbox("ESP Player Count", &isESPObjectsCount);
                ImGui::EndTabItem();                    
            }
            ImGui::Separator();
            ImGui::Text("Time-consuming To Draw %.3f ms (%.1f FPS)", 1000.0f / io.Framerate, io.Framerate);         
            ImGui::EndTabBar();

        }
    }
}

MonoArray<void**>*playersList = NULL;
void *get_type = NULL;      
void *camera = NULL;

void DrawESP(ImDrawList *draw, int screenWidth, int screenHeight) {
        
   if (!bInitDone) return;
     
   if(isESPObjectsCount && playersList != NULL) {      
       string playerCount = to_string(playersList->getLength());
       Drawing::DrawText(17, ImVec2(screenWidth / 2, screenHeight / 2),ImColor(255,255,255,255), playerCount.c_str());   
   }
    
   if(isESP) {
       
      if(Screen_SetResolution != NULL) {
        Screen_SetResolution(screenWidth, screenHeight, true);    
      }
           
      // Search for players via tag, works completely without crashes but very slow ( Unity - Manual )    
      //if(GameObject_FindGameObjectsWithTag(Il2CppString::CreateMonoString("Player"))) {
          //playersList = GameObject_FindGameObjectsWithTag(Il2CppString::CreateMonoString("Player"));
      //}
           
      if(Type_GetTypeName(Il2CppString::CreateMonoString("Player,Assembly-CSharp"))) {
        get_type = Type_GetTypeName(Il2CppString::CreateMonoString("Player,Assembly-CSharp"));
      } 
     
      if(get_type != NULL) {
        playersList = Object_FindObjectsOfType(get_type); 
      }       
      
      if(playersList != NULL && playersList->getLength() > 0) { 
       
       for (int i = 0; i < playersList->getLength(); i++) {
       auto Player = playersList->getPointer()[i];     
                 
       if(Camera_get_current != NULL) {
         camera = Camera_get_current();
       }
       if(CameraManager_get_MainCamera != NULL) {
         camera = CameraManager_get_MainCamera(); 
       }
       if(Camera_get_main() != NULL) {
          camera = Camera_get_main(); 
	    }	
            
        if(Player != NULL && Object_IsNativeObjectAlive(Player) && Tools::IsPtrValid(Player) && camera != NULL && m_CachedPtr(Player)) {      
                  
           auto bottomPos = Vector3(Transform_getPosition(Player).X,0,Transform_getPosition(Player).Z);   
           auto topPos = Vector3(Transform_getPosition(Player).X,2,Transform_getPosition(Player).Z); 
           
           auto playerBottom = Camera_WorldToScreen(camera,bottomPos);
           auto playerTop = Camera_WorldToScreen(camera,topPos);
                    
           if(playerBottom.Z < 1.f) continue;
           if(playerTop.Z < 1.f) continue;
          
           auto boxHeight = abs(playerTop.Y - playerBottom.Y);
           auto boxWidth = boxHeight * 0.60f;
            
           auto playerRect = Rect(playerTop.X - (boxWidth / 2), (screenHeight - playerTop.Y), boxWidth, boxHeight);                                                                             
                
           if(isESPLine) {
             draw->AddLine(ImVec2(screenWidth / 2, 0), ImVec2(playerTop.X, screenHeight - playerTop.Y), ImColor(255,255,255,255), 1);  
           }
          
           if(isESPBox) {
              Drawing::DrawBox(playerRect, 1, ImColor(255,255,255,255)); 
           }
          
           if(isESPDistance) { 
            char extra[30];                
            auto distance = Vector3::Distance(Transform_getPosition(Component_get_transform(camera)),Transform_getPosition(Player));  
            sprintf(extra, "%0.0f m", distance);          
		    Drawing::DrawText(15, ImVec2(playerRect.x + (playerRect.width / 2),playerRect.y + playerRect.height + 10.0f), ImColor(255,255,255,255), extra);   
          }      
        }            
      }
    }
  }                 
}

void *hack_thread(void *) {
   
     do {
        sleep(1);
    } while (!isLibraryLoaded(libName));
      
    Il2CppAttach();
    sleep(5);  
    
    Object_Destroy = (void *(*)(void*)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Object", "Destroy", 1);
    Camera_WorldToScreen = (Vector3 (*)(void *, Vector3)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "WorldToScreenPoint", 1);
    Component_get_transform = (void *(*)(void *)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Component", "get_transform", 0);
    Transform_get_position = (Vector3 (*)(void *)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Transform", "get_position", 0);
    Object_FindObjectsOfType = (MonoArray<void**>*(*)(void*)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Object", "FindObjectsOfType", 1);    
    Type_GetTypeName = (void *(*)(MonoString*)) (uintptr_t) Il2CppGetMethodOffset("mscorlib.dll", "System", "Type", "GetType", 1);           
    GameObject_get_transform = (void *(*)(void*)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "GameObject", "get_transform", 0);
    Object_IsNativeObjectAlive = (bool *(*)(void*)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Object", "IsNativeObjectAlive", 1);  
    GameObject_FindGameObjectsWithTag = (MonoArray<void**>*(*)(MonoString*)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "GameObject", "FindGameObjectsWithTag", 1);
    Camera_get_main = (void *(*)()) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "get_main", 0);
	Camera_get_current = (void *(*)()) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Camera", "get_current", 0);
    CameraManager_get_MainCamera = (void *(*)()) (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "", "CameraManager", "get_MainCamera", 0);
    GameObject_get_gameObject = (void *(*)(void*)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "GameObject", "get_gameObject", 0); 
    Screen_SetResolution = (void (*)(int, int, bool)) (uintptr_t) Il2CppGetMethodOffset("UnityEngine.dll", "UnityEngine", "Screen", "SetResolution", 1);
          
    bInitDone = true;
    
    return NULL;
}

#endif
